function teste(){
    alert('Tenha uma boa semana :)');
}