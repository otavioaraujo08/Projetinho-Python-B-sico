from django.shortcuts import render
from django.shortcuts import get_object_or_404

from django.http import HttpResponse
from django.http import HttpResponseNotFound

from .models import Produto

def index(request):
    produtos = Produto.objects.all()

    context = {
        'Curso': 'Programação Web com Django Framework.',
        'Django': 'Django é coisa de maluco.',
        'produtos': produtos
    }
    return render(request, 'index.html', context)

def contato(request):
    return render(request, 'contato.html')

def produto(request, pk):
    # prod = Produto.objects.get(id=pk)
    prod = get_object_or_404(Produto, id=pk)

    context = {
        'produto': prod
    }
    return render(request, 'produto.html', context)

def error404(request, ex):
    return HttpResponseNotFound('Erro 404: Página Não Encontrada.')

def error500(request):
    return HttpResponseNotFound('Erro 500: Falha No Processamento.')